"""Sensore for pillefyret — platform: pillefyr i configuration.yaml."""
import logging

from homeassistant.components.sensor import SensorEntity
from homeassistant.helpers.update_coordinator import CoordinatorEntity

from . import DOMAIN

LOGGER = logging.getLogger(__name__)

# de vigtigste værdier får egne entiteter; resten lander som attributter
MAIN = [
    ("advanced.actual_boiler_temp", "Pillefyr temperatur", "°C", "temperature"),
    ("advanced.boiler_setpoint", "Pillefyr setpunkt", "°C", "temperature"),
    ("advanced.boiler_diff", "Pillefyr diff", "°C", None),
    ("boiler.temp", "Pillefyr boiler setpunkt", "°C", None),
    ("misc.wifi_network_status", "Pillefyr netværk", None, None),
    ("vacuum.output_auger", "Pillefyr snegle", "%", None),
    ("vacuum.output_vacuum", "Pillefyr vacuum", "%", None),
    ("misc.dl_version", "Pillefyr firmware", None, None),
]


async def async_setup_platform(hass, config, add_entities, discovery_info=None):
    coordinator = hass.data[DOMAIN]["coordinator"]

    class PilleFyrSensor(CoordinatorEntity, SensorEntity):
        def __init__(self, key, name, unit, dev_class):
            super().__init__(coordinator)
            self._key = key
            self._attr_name = name
            self._attr_unique_id = f"pillefyr_{key.replace('.', '_')}"
            self._attr_native_unit_of_measurement = unit
            self._attr_device_class = dev_class

        @property
        def native_value(self):
            return (self.coordinator.data or {}).get(self._key)

        @property
        def extra_state_attributes(self):
            return {k: v for k, v in (self.coordinator.data or {}).items()
                    if k != self._key}

    entities = [PilleFyrSensor(key, name, unit, dc) for key, name, unit, dc in MAIN]
    add_entities(entities, update_before_add=True)
    LOGGER.info("Pillefyr: %d sensore oprettet", len(entities))
